Dim score, totaalVragen, i, getal1, getal2, juistAntwoord, gebruikersAntwoord

score = 0
totaalVragen = 10

' Start het spel met een welkom
MsgBox "Welkom bij de Wiskunde Game! Je krijgt 10 optelsommen.", 64, "Wiskunde Matej Game"

' Zorg voor willekeurige getallen bij elke start
Randomize

' Loop 10 keer voor de 10 vragen
For i = 1 To totaalVragen
    ' Genereer twee willekeurige getallen tussen 1 en 50
    getal1 = Int((50 * Rnd) + 1)
    getal2 = Int((50 * Rnd) + 1)
    juistAntwoord = getal1 + getal2
    
    ' Vraag het antwoord aan de gebruiker
    gebruikersAntwoord = InputBox("Vraag " & i & " van " & totaalVragen & vbCrLf & vbCrLf & _
                                  "Hoeveel is " & getal1 & " + " & getal2 & "?", "Bereken de som")
    
    ' Controleer of de gebruiker heeft geannuleerd of niks heeft ingevuld
    If gebruikersAntwoord = "" Then
        MsgBox "Quiz afgebroken! Je score tot nu toe is: " & score & "/" & (i - 1), 48, "Gestopt"
        WScript.Quit
    End If
    
    ' Controleer of het antwoord juist is
    If CInt(gebruikersAntwoord) = juistAntwoord Then
        MsgBox "Goed zo! Dat is correct.", 64, "Juist!"
        score = score + 1
    Else
        MsgBox "Helaas, dat is fout. Het juiste antwoord was: " & juistAntwoord, 16, "Onjuist"
    End If
Next

' Eindscore tonen
MsgBox "De quiz is afgelopen!" & vbCrLf & "Jouw totale score is: " & score & " van de " & totaalVragen & " goed.", 64, "Resultaat"
