import random
import tkinter as tk
from tkinter import messagebox


class MathGame:

  def __init__(self, root):
    self.root = root
    self.root.title("Math Dash Game")
    self.root.geometry("400x450")
    self.root.config(bg="#f0f4f8")
    self.root.resizable(False, False)

    # Game variables
    self.score = 0
    self.time_left = 30
    self.timer_running = False
    self.num1 = 0
    self.num2 = 0
    self.operator = "+"
    self.correct_answer = 0

    # UI Styling
    self.font_title = ("Helvetica", 18, "bold")
    self.font_normal = ("Helvetica", 12)
    self.font_bold = ("Helvetica", 12, "bold")
    self.font_large = ("Helvetica", 24, "bold")

    self.create_widgets()

  def create_widgets(self):
    # Title Label
    self.title_label = tk.Label(
        self.root,
        text="Math Dash 🚀",
        font=self.font_title,
        bg="#f0f4f8",
        fg="#1e293b",
    )
    self.title_label.pack(pady=15)

    # Info Frame (Score and Timer)
    self.info_frame = tk.Frame(self.root, bg="#f0f4f8")
    self.info_frame.pack(fill="x", padx=30, pady=5)

    self.score_label = tk.Label(
        self.info_frame,
        text="Score: 0",
        font=self.font_bold,
        bg="#f0f4f8",
        fg="#0284c7",
    )
    self.score_label.pack(side="left")

    self.timer_label = tk.Label(
        self.info_frame,
        text="Time: 30s",
        font=self.font_bold,
        bg="#f0f4f8",
        fg="#dc2626",
    )
    self.timer_label.pack(side="right")

    # Game Card Frame
    self.card_frame = tk.Frame(
        self.root, bg="white", bd=2, relief="groove", padx=20, pady=20
    )
    self.card_frame.pack(padx=30, pady=15, fill="both")

    # Problem Label
    self.problem_label = tk.Label(
        self.card_frame,
        text="Press Start!",
        font=self.font_large,
        bg="white",
        fg="#334155",
    )
    self.problem_label.pack(pady=10)

    # Answer Entry
    self.answer_entry = tk.Entry(
        self.card_frame,
        font=self.font_large,
        justify="center",
        width=8,
        bd=2,
        relief="solid",
    )
    self.answer_entry.pack(pady=10)
    self.answer_entry.bind("<Return>", self.check_answer)
    self.answer_entry.config(state="disabled")

    # Submit Button
    self.submit_btn = tk.Button(
        self.card_frame,
        text="Submit",
        font=self.font_bold,
        bg="#0ea5e9",
        fg="white",
        activebackground="#0284c7",
        activeforeground="white",
        bd=0,
        padx=15,
        pady=5,
        command=self.check_answer,
        state="disabled",
    )
    self.submit_btn.pack(pady=5)

    # Control Button (Start / Restart)
    self.control_btn = tk.Button(
        self.root,
        text="Start Game",
        font=self.font_bold,
        bg="#22c55e",
        fg="white",
        activebackground="#16a34a",
        activeforeground="white",
        bd=0,
        padx=20,
        pady=8,
        command=self.start_game,
    )
    self.control_btn.pack(pady=15)

    # Feedback Label
    self.feedback_label = tk.Label(
        self.root, text="", font=self.font_normal, bg="#f0f4f8", fg="#64748b"
    )
    self.feedback_label.pack()

  def start_game(self):
    self.score = 0
    self.time_left = 30
    self.timer_running = True
    self.score_label.config(text=f"Score: {self.score}")
    self.timer_label.config(text=f"Time: {self.time_left}s")

    self.control_btn.config(state="disabled")
    self.answer_entry.config(state="normal")
    self.submit_btn.config(state="normal")
    self.feedback_label.config(text="")

    self.answer_entry.focus()
    self.next_problem()
    self.countdown()

  def next_problem(self):
    if not self.timer_running:
      return

    # Choose a random operation (+, -, *)
    self.operator = random.choice(["+", "-", "*"])

    if self.operator == "+":
      self.num1 = random.randint(1, 50)
      self.num2 = random.randint(1, 50)
      self.correct_answer = self.num1 + self.num2
    elif self.operator == "-":
      self.num1 = random.randint(10, 50)
      self.num2 = random.randint(1, self.num1)  # Avoid negative results
      self.correct_answer = self.num1 - self.num2
    else:  # Multiplication
      self.num1 = random.randint(1, 12)
      self.num2 = random.randint(1, 12)
      self.correct_answer = self.num1 * self.num2

    self.problem_label.config(text=f"{self.num1} {self.operator} {self.num2} = ?")
    self.answer_entry.delete(0, tk.END)

  def check_answer(self, event=None):
    if not self.timer_running:
      return

    user_input = self.answer_entry.get().strip()

    try:
      user_answer = int(user_input)
      if user_answer == self.correct_answer:
        self.score += 1
        self.score_label.config(text=f"Score: {self.score}")
        self.feedback_label.config(text="Correct! 🎉", fg="#16a34a")
        self.next_problem()
      else:
        self.feedback_label.config(text="Incorrect. Try again!", fg="#dc2626")
        self.answer_entry.delete(0, tk.END)
    except ValueError:
      self.feedback_label.config(
          text="Please enter a valid number.", fg="#d97706"
      )
      self.answer_entry.delete(0, tk.END)

  def countdown(self):
    if self.time_left > 0:
      self.time_left -= 1
      self.timer_label.config(text=f"Time: {self.time_left}s")
      self.root.after(1000, self.countdown)
    else:
      self.end_game()

  def end_game(self):
    self.timer_running = False
    self.answer_entry.config(state="disabled")
    self.submit_btn.config(state="disabled")
    self.control_btn.config(text="Play Again", state="normal")
    self.problem_label.config(text="Time's Up! ⏰")
    self.feedback_label.config(
        text=f"Final Score: {self.score}", fg="#0284c7"
    )
    messagebox.showinfo(
        "Game Over", f"Time is up!\nYour final score is: {self.score}"
    )


if __name__ == "__main__":
  root = tk.Tk()
  game = MathGame(root)
  root.mainloop()